package moed.application.MOED_app.business;

import moed.application.MOED_app.Entities.Stats;
import org.jfree.data.xy.XYDataItem;
import org.jfree.data.xy.XYSeries;

import java.util.List;

public class DataAnalyzer {
    public static class Statistics {
        public static Stats getStats(XYSeries series) {
            Double[] arrMinMax = getMinMax(series);
            return new Stats(
                    arrMinMax[0],
                    arrMinMax[1],
                    getAverage(series),
                    getMomentum(2, series),
                    getMeanDeviation(series),
                    getMomentum(2, series, false),
                    getRootMeanSquareError(series),
                    getAsymmetricalIndex(series),
                    getKurtosisIndex(series),
                    isStationary(10, series)
            );
        }

        public static Double[] getMinMax(XYSeries series) {
            Double[] result = new Double[2];
            result[0] = series.getMinY();
            result[1] = series.getMaxY();
            return result;
        }

        public static Double getAverage(XYSeries series) {
            int N = series.getItemCount();
            double xSum = 0;
            for (var item : (List<XYDataItem>) series.getItems()) {
                xSum += item.getYValue();
            }
            return xSum / N;
        }

        public static Double getMomentum(int pow, XYSeries series, boolean... withAverage) {
            double avg = (withAverage.length == 0 || withAverage[0]) ? getAverage(series) : 0;
            int N = series.getItemCount();
            double sum = 0;
            for (var item : (List<XYDataItem>) series.getItems()) {
                sum += Math.pow(item.getYValue() - avg, pow);
            }
            return sum / N;
        }

        public static Double getMeanDeviation(XYSeries series) {
            return Math.sqrt(getMomentum(2, series));
        }

        public static Double getRootMeanSquareError(XYSeries series) {
            return Math.sqrt(getMomentum(2, series, false));
        }

        public static Double getAsymmetricalIndex(XYSeries series) {
            return getMomentum(3, series) / Math.pow(getMeanDeviation(series), 3);
        }

        public static Double getKurtosisIndex(XYSeries series) {
            return getMomentum(4, series) / Math.pow(getMeanDeviation(series), 4) - 3;
        }

        public static boolean isStationary(int splitCount, XYSeries series) {
            final Double[] averages = new Double[splitCount];
            final Double[] meanDeviations = new Double[splitCount];
            final int delta = series.getItemCount() / splitCount;
            final XYSeries[] dataSeries = new XYSeries[splitCount];

            for (int i = 0; i < splitCount; i++) {
                int start = delta * i;
                dataSeries[i] = new XYSeries("");
                for (int j = start; j < start + delta; j++) {
                    if (j >= series.getItemCount()) break;
                    dataSeries[i].add(series.getDataItem(j));
                }
            }
            for (int i = 0; i < splitCount; i++) {
                averages[i] = getAverage(dataSeries[i]);
                meanDeviations[i] = getMeanDeviation(dataSeries[i]);
            }
            for (int i = 0; i < splitCount; i++) {
                for (int j = i + 1; j < splitCount; j++) {
                    if (i == j) continue;
                    if (Math.abs((averages[i] - averages[j]) / getMinMax(series)[1] * 100) > 10) return false;
                }
                for (int j = i + 1; j < splitCount; j++) {
                    if (i == j) continue;
                    if (Math.abs((meanDeviations[i] - meanDeviations[j]) / getMinMax(series)[1] * 100) > 10) return false;
                }
            }

            return true;
        }
    }
}
