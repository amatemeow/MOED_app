package moed.application.MOED_app.ENUM;

public enum RandomType {
    SYSTEM,
    SELF
}
