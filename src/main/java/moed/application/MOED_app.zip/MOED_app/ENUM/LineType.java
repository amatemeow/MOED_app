package moed.application.MOED_app.ENUM;

public enum LineType {
    SIMPLE,
    EXPONENT,
    COMBINED,
    NOISE,
    IMPULSE_NOISE
}
