package moed.application.MOED_app.Entities;

import com.google.gson.GsonBuilder;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import moed.application.MOED_app.business.DataAnalyzer;
import moed.application.MOED_app.business.DataModeller;

import java.io.IOException;

public class TrendInfo {
    @Getter private String trendPath;
    @NonNull @Getter private final Trend trend;
    @NonNull @Getter private final Stats stats;
    @Getter private String statsJSON;

    public TrendInfo(Trend trend) {
        this.trend = trend;
        this.stats = DataAnalyzer.Statistics.getStats(trend.getSeries());
        try {
            this.statsJSON = new GsonBuilder().setPrettyPrinting().create().toJson(this.stats);
        } catch (RuntimeException re) {
            re.printStackTrace();
        }
        try {
            this.trendPath = DataModeller.getTrend(this.trend);
        } catch (IOException IOE) {
            IOE.printStackTrace();
        }

    }
}
