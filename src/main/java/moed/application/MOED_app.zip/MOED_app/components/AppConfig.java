package moed.application.MOED_app.components;

import lombok.Getter;
import moed.application.MOED_app.ENUM.LineType;
import moed.application.MOED_app.ENUM.RandomType;
import moed.application.MOED_app.Entities.Trend;
import moed.application.MOED_app.business.DataModeller;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.PostConstruct;
import java.util.ArrayList;

@Configuration
@EnableWebMvc
@ComponentScan
public class AppConfig implements WebMvcConfigurer {

    @Component
    public static class IOCConfig {
        public static final String CHART_FOLDER_WEB = "images";
        public static final String CLEAN_PATH = CHART_FOLDER_WEB;
    }

    @Component
    public static class SampleData {
        @Getter
        private final ArrayList<Trend> TRENDS = new ArrayList<>();

        @PostConstruct
        public void populateTrends() {
            TRENDS.add(new Trend("Straight Positive"));
            TRENDS.add(new Trend("Straight Negative", false));
            TRENDS.add(new Trend(
                    LineType.EXPONENT,
                    1000,
                    0.005,
                    50,
                    true,
                    "Exponential Positive"));
            TRENDS.add(new Trend(
                    LineType.EXPONENT,
                    1000,
                    0.005,
                    50,
                    false,
                    "Exponential Negative"));
            TRENDS.add(new Trend(
                    LineType.COMBINED,
                    1000,
                    0.005,
                    100,
                    true,
                    "Combined Chart"));
            TRENDS.add(new Trend(
                    10000, 10.5, RandomType.SYSTEM, "System Noise"));
            TRENDS.add(new Trend(
                    10000, 105.15, RandomType.SELF, "Custom Noise"));
            TRENDS.add(DataModeller.getShiftedTrend(
                    new Trend("Shifted"), 569.2, 16, 650));
            TRENDS.add(new Trend(
                    LineType.IMPULSE_NOISE, 1000, 50.8, 78.5, 0.006, RandomType.SYSTEM, "Impulse Noise"));
            TRENDS.add(new Trend("Harmonic").setSeries(DataModeller.getHarm(1000, 100, 33, 0.001)));
            TRENDS.add(new Trend("Harmonic, but deltaT is wrong").setSeries(DataModeller.getHarm(1000, 100, 333, 0.001)));
            TRENDS.add(new Trend("Poly Harmonic").setSeries(
                    DataModeller.getPolyHarm(1000, new int[] {100, 15, 10}, new int[] {33, 5, 170}, 0.001)));
        }

        public Double[] getSampleData(int N) {
            final Double[] sampleData = new Double[N];
            for (int i = 0; i < N; i++) {
                sampleData[i] = (double) i;
            }

            return sampleData;
        }
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/images/**", "/css/**", "/img/**", "/js/**")
                .addResourceLocations("file:" + "images" + "/", "classpath:/static/css/","classpath:/static/img/",
                        "classpath:/static/js/");
    }
}
